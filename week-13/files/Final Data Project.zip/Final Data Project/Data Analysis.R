# Arda Cab Utkan
library(tidyverse)
library(janitor)
library(lubridate)
library(DT)
library(knitr)

# Gather data. We will use population and emigration later.
births <- read_csv("data/children-born-per-woman.csv")
womenlabor <- read_csv("data/female-labor-force-participation-rates.csv")
gdi <- read_csv("data/gender-development-index.csv")
gni <- read_csv("data/gross-national-income-per-capita-undp.csv")
hdi <- read_csv("data/human-development-index.csv")

# Look Inside
glimpse(births)
glimpse(gdi)
glimpse(gni)
glimpse(hdi)
glimpse(womenlabor)

# Cursory analysis suggests the best available time-span is 1992-2022 (30 years). 2023 is missing for most.
births <- births |> 
  filter(Year == 1992 | Year == 2022)
gdi <- gdi |> 
  filter(Year == 1992 | Year == 2022)
gni <- gni |> 
  filter(Year == 1992 | Year == 2022)
hdi <- hdi |> 
  filter(Year == 1992 | Year == 2022)
womenlabor <- womenlabor |> 
  filter(Year == 1992 | Year == 2022)

# Global birth rate went from ~3 to ~2.2 in the time-span of our study.

# Uncoded regions are non-countries; not needed for us. Also get rid of "World".
births <- births |> 
  filter(Code != "" & Code != "OWID_WRL")
gdi <- gdi |> 
  filter(Code != "" & Code != "OWID_WRL")
gni <- gni |> 
  filter(Code != "" & Code != "OWID_WRL")
hdi <- hdi |> 
  filter(Code != "" & Code != "OWID_WRL")
womenlabor <- womenlabor |> 
  filter(Code != "" & Code != "OWID_WRL")

# Data varies in observation count. Countries missing?
births |> 
  group_by(Code) |> 
  summarize(n()) |> 
  arrange(n())
gdi |> 
  group_by(Code) |> 
  summarize(n()) |> 
  arrange(n())

# Some holes in data. We need to untidy seperately.
births_wide <- births |> 
  pivot_wider(names_from = Year,
              values_from = `Fertility rate (period), historical`) |> 
  rename(births1992 = "1992") |> 
  rename(births2022 = "2022")
gdi_wide <- gdi |> 
  pivot_wider(names_from = Year,
              values_from = `Gender Development Index`) |> 
  rename(gdi1992 = "1992") |> 
  rename(gdi2022 = "2022")
gni_wide <- gni |> 
  pivot_wider(names_from = Year,
              values_from = `Gross national income per capita`) |> 
  rename(gni1992 = "1992") |> 
  rename(gni2022 = "2022")
hdi_wide <- hdi |> 
  pivot_wider(names_from = Year,
              values_from = `Human Development Index`) |> 
  rename(hdi1992 = "1992") |> 
  rename(hdi2022 = "2022")
womenlabor_wide <- womenlabor |> 
  pivot_wider(names_from = Year,
              values_from = `Labor force participation rate, female (% of female population ages 15+) (modeled ILO estimate)`) |> 
  rename(womenlabor1992 = "1992") |> 
  rename(womenlabor2022 = "2022")

# Ensure codes do not repeat to allow joins.
births_wide |> 
  group_by(Code) |> 
  summarize(n()) |> 
  arrange(desc(n()))
gdi_wide |> 
  group_by(Code) |> 
  summarize(n()) |> 
  arrange(desc(n()))
gni_wide |> 
  group_by(Code) |> 
  summarize(n()) |> 
  arrange(desc(n()))
hdi_wide |> 
  group_by(Code) |> 
  summarize(n()) |> 
  arrange(desc(n()))
womenlabor_wide |> 
  group_by(Code) |> 
  summarize(n()) |> 
  arrange(desc(n()))

# Joins on Code now possible.
births_gdi <- left_join(births_wide, gdi_wide, by = "Code") |> 
  select(-Entity.y) |> 
  rename(Entity = "Entity.x") 
births_gdi_gni <- left_join(births_gdi, gni_wide, by = "Code") |> 
  select(-Entity.y) |> 
  rename(Entity = "Entity.x")
births_gdi_gni_hdi <- left_join(births_gdi_gni, hdi_wide, by = "Code") |> 
  select(-Entity.y) |> 
  rename(Entity = "Entity.x")
correlations <- left_join(births_gdi_gni_hdi, womenlabor_wide, by = "Code") |> 
  select(-Entity.y) |> 
  rename(Entity = "Entity.x")

# This beautiful abomination is the table for which we will conduct our correlation analysis. It will also be the table used in our markdown story. A lot of missing data here, but such is the way of data on a global scale.

# QUESTION: How many nations are below replacement (2.1 births per woman)?

# Create replacement boolean
correlations <- correlations |> 
  mutate(repstatus1992 = if_else(births1992 >= 2.1, "At Replacement", "Not at Replacement"), repstatus2022 = if_else(births2022 >= 2.1, "At Replacement", "Not at Replacement"))

# Obtain replacement numbers
correlations |> 
  group_by(repstatus1992) |> 
  summarize(n())

correlations |> 
  group_by(repstatus2022) |> 
  summarize(n())

# ANSWER: The number of nations no longer at replacement rate has nearly doubled from 67 to 128 between 1992 and 2022. The majority of nations globally are in the red for the most recently available data.

# QUESTION: Which nations experienced the most precipitous drop-off in birth rate during the time-span?

# Add birth rate change variable.
correlations <- correlations |> 
  mutate(bpw_change = births2022 - births1992)

# Graph it
correlations |> 
  arrange(bpw_change) |> 
  head(20) |> 
  ggplot(aes(bpw_change, reorder(Entity, -bpw_change))) +
  geom_col()

# Technically answers the question, but each nation here was developing with absolutely massive birth rates; human geographers would have already anticipated these changes.

# Let's see the highest drop-off in nations that went below replacement.
correlations |> 
  filter(repstatus2022 == "Not at Replacement") |> 
  arrange(bpw_change) |> 
  head(20) |> 
  ggplot(aes(bpw_change, reorder(Entity, -bpw_change))) +
  geom_col()

# ANSWER: Maldives and Bhutan saw the most substantial decrease in birth rate among nations that went below replacement in 2022, but those nations are incredibly small. However, among the top 20 in this metric also includes Iran, the Philippines, India, Malaysia and Nepal. These nations have large populations ranging from the tens of millions to over one billion, yet they've all tanked below replacement in a matter of three decades.

# QUESTION: Does the change in strength of a nation's economy correlate with its birth rate?

# Add gni change variable
correlations <- correlations |> 
  mutate(gni_change = gni2022 - gni1992)

# Create a scatterplot with a trend line
correlations |> 
  ggplot(aes(gni_change, bpw_change)) +
  geom_point() +
  geom_smooth(method = lm) +
  expand_limits(y=0)

# Calculate correlation
cor_nona_gnibpw <- correlations |> 
  filter(gni_change != "", bpw_change != "")

cor(cor_nona_gnibpw$gni_change, cor_nona_gnibpw$bpw_change)

# ANSWER: A strengthening economy through the time-span only weakly positively correlated to an increasing birth rate.

# QUESTION: Did HDI/GNI or the proportion of women in the labor force affect birth rate.

# Create change variables
correlations <- correlations |> 
  mutate(hdi_change = hdi2022 - hdi1992)
correlations <- correlations |> 
  mutate(gdi_change = gdi2022 - gdi1992)
correlations <- correlations |> 
  mutate(womenlabor_change = womenlabor2022 - womenlabor1992)

# Scatterplots with trend lines for each variable
correlations |> 
  ggplot(aes(hdi_change, bpw_change)) +
  geom_point() +
  geom_smooth(method = lm) +
  expand_limits(y=0)
correlations |> 
  ggplot(aes(gdi_change, bpw_change)) +
  geom_point() +
  geom_smooth(method = lm) +
  expand_limits(y=0)
correlations |> 
  ggplot(aes(womenlabor_change, bpw_change)) +
  geom_point() +
  geom_smooth(method = lm) +
  expand_limits(y=0)

# Calculate correlations
cor_nona_hdibpw <- correlations |> 
  filter(hdi_change != "", bpw_change != "")

cor(cor_nona_hdibpw$hdi_change, cor_nona_hdibpw$bpw_change)

cor_nona_gdibpw <- correlations |> 
  filter(gdi_change != "", bpw_change != "")

cor(cor_nona_gdibpw$gdi_change, cor_nona_gdibpw$bpw_change)

cor_nona_womenlaborbpw <- correlations |> 
  filter(womenlabor_change != "", bpw_change != "")

cor(cor_nona_womenlaborbpw$womenlabor_change, cor_nona_womenlaborbpw$bpw_change)

# As additional confirmation, checking the 2022 ONLY correlations
correlations_nona <- correlations |> 
  filter(births2022 != "", gni2022 != "", gdi2022 != "", hdi2022 != "", womenlabor2022 != "")

cor(correlations_nona$gni2022, correlations_nona$births2022)
cor(correlations_nona$gdi2022, correlations_nona$births2022)
cor(correlations_nona$hdi2022, correlations_nona$births2022)
cor(correlations_nona$womenlabor2022, correlations_nona$births2022)

# ANSWER: Nations that had high national income, gdi and hdi in 2022 had correlating low birth rates and vise versa (moderate correlation, strong correlation in the case of hdi). No correlation existed in 2022 between proportions of women in the labor force and birth rate. For the change in these data points over the time-span, gni was only weakly correlated, hdi and labor force proportions had no correlation and gdi had a moderate negative correlation.

# NOTE: Upon further analysis, gdi correlation is a poor case due to the extreme proportion (about half) of nations without 1992 data. Purely 2022 data is still robust.

# For even more confirmation, check the 1992 data alone as well.
# As additional confirmation, checking the 2022 ONLY correlations
correlations_nona_1992 <- correlations |> 
  filter(births1992 != "", gni1992 != "", gdi1992 != "", hdi1992 != "", womenlabor1992 != "")

cor(correlations_nona_1992$gni1992, correlations_nona_1992$births1992)
cor(correlations_nona_1992$gdi1992, correlations_nona_1992$births1992)
cor(correlations_nona_1992$hdi1992, correlations_nona_1992$births1992)
cor(correlations_nona_1992$womenlabor1992, correlations_nona_1992$births1992)

# Correlations appear similar.

# QUESTION: Gender Development Index is a statistic that should ideally be high, so are there any nations that can beat the correlation (maintain it and remain above replacement)?
correlations |> 
  filter(gdi2022 >= 0.95) |> 
  arrange(desc(births2022)) |> 
  head(20) |> 
  ggplot(aes(births2022, reorder(Entity, births2022))) +
  geom_col()

# Other stats
correlations |> 
  filter(hdi2022 >= 0.9) |> 
  arrange(desc(births2022)) |> 
  head(20) |> 
  ggplot(aes(births2022, reorder(Entity, births2022))) +
  geom_col()

correlations |> 
  filter(gni2022 >= 40000) |> 
  arrange(desc(births2022)) |> 
  head(20) |> 
  ggplot(aes(births2022, reorder(Entity, births2022))) +
  geom_col()

# ANSWER: A decent number of island nations, central Asian nations and African nations maintain high gdi and are at replacement. Israel is the only high hdi nation at replacement, and Israel and Saudi Arabia are the only wealthy nations with high birth rate.

# Creating a simple graph for fertility rate in general since I haven't done that yet.
correlations |> 
  arrange(desc(births2022)) |>  
  head(20) |> 
  ggplot(aes(births2022, reorder(Entity, births2022))) +
  geom_col()

correlations |> 
  arrange(births2022) |>  
  head(20) |> 
  ggplot(aes(births2022, reorder(Entity, -births2022))) +
  geom_col()